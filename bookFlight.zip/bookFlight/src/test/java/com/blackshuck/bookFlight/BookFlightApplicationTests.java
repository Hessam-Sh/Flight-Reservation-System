package com.blackshuck.bookFlight;

import com.blackshuck.bookFlight.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookFlightApplicationTests {

	@Test
	void contextLoads()
	{

	}

}
