package com.blackshuck.bookFlight.enums;

public enum BookingStatus
{
    CONFIRMED,
    CANCELED,
    PENDING
}
