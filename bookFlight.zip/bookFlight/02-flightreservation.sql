CREATE DATABASE `flightreservation`;
USE `flightreservation`;

CREATE TABLE `user`
(
	`user_id` int NOT NULL AUTO_INCREMENT,
    `email` varchar(225) DEFAULT NULL,
    `password` varchar(225) DEFAULT NULL,
    `registration_date` datetime(0) DEFAULT NULL,
    `is_active` bit(1) DEFAULT NULL,
    `is_admin` bit(1) DEFAULT NULL,
    PRIMARY KEY (`user_id`),
    UNIQUE KEY (`email`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `passenger`
(
	`passenger_id` int NOT NULL AUTO_INCREMENT,
    `first_name` varchar(225) DEFAULT NULL,
    `last_name` varchar(225) DEFAULT NULL,
    `national_code` varchar(225) DEFAULT NULL,
    `born_date`date DEFAULT NULL,
    `phone_number` varchar(225) DEFAULT NULL,
    PRIMARY KEY (`passenger_id`),
    UNIQUE KEY (`national_code`),
    UNIQUE KEY (`phone_number`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `airport`
(
	`airport_id` int NOT NULL AUTO_INCREMENT,
    `name` varchar(225) DEFAULT NULL,
    `city` varchar(225) DEFAULT NULL,
    `country` varchar(225) DEFAULT NULL,
    PRIMARY KEY (`airport_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `airline`
(
	`airline_id` int NOT NULL AUTO_INCREMENT,
    `name` varchar(225) DEFAULT NULL,
    `plane_type` varchar(225) DEFAULT NULL,
    `logo_url` varchar(225) DEFAULT NULL,
    PRIMARY KEY (`airline_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `flight`
(
	`flight_id` int NOT NULL AUTO_INCREMENT,
    `origin` varchar(225) DEFAULT NULL,
    `destination` varchar(225) DEFAULT NULL,
    `departure_date`date DEFAULT NULL,
    `takeoff_time` time DEFAULT NULL,
    `landing_time` time DEFAULT NULL,
    `capacity` int DEFAULT NULL,
    `origin_airport_id` int DEFAULT NULL,
    `destination_airport_id` int DEFAULT NULL,
    `airline_id` int DEFAULT NULL,
    PRIMARY KEY (`flight_id`),
    FOREIGN KEY (`origin_airport_id`) REFERENCES `airport` (`airport_id`),
    FOREIGN KEY (`destination_airport_id`) REFERENCES `airport` (`airport_id`),
    FOREIGN KEY (`airline_id`) REFERENCES `airline` (`airline_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `ticket`
(
	`ticket_id` int NOT NULL AUTO_INCREMENT,
    `seat_number` varchar(225) DEFAULT NULL,
    `seat_class` varchar(225) DEFAULT NULL,
    `ticket_date`datetime(0) DEFAULT NULL,
    `price` int DEFAULT NULL,
    `flight_id` int DEFAULT NULL,
    `passenger_id` int DEFAULT NULL,
    PRIMARY KEY (`ticket_id`),
    FOREIGN KEY (`flight_id`) REFERENCES `flight` (`flight_id`),
    FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `booking`
(
	`booking_id` int NOT NULL AUTO_INCREMENT,
    `booking_code` varchar(225) DEFAULT NULL,
	`booking_date` datetime(0) DEFAULT NULL,
    `booking_status` varchar(225) DEFAULT NULL,
	`created_at` datetime(0) DEFAULT NULL,
	`passenger_id` int DEFAULT NULL,
	`flight_id` int DEFAULT NULL,
	`user_id` int DEFAULT NULL,
	PRIMARY KEY (`booking_id`),
    FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`),
    FOREIGN KEY (`flight_id`) REFERENCES `flight` (`flight_id`),
    FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `chat_session`
(
	`chat_session_id` int NOT NULL AUTO_INCREMENT,
    `started_at` datetime(0) DEFAULT NULL,
    `ended_at` datetime(0) DEFAULT NULL,
    `user_id` int DEFAULT NULL,
    PRIMARY KEY (`chat_session_id`),
    FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `chat_message`
(
	`chat_message_id` int NOT NULL AUTO_INCREMENT,
    `sender` enum('USER', 'BOT') NOT NULL DEFAULT 'USER',
    `message` text DEFAULT NULL,
    `created_at` datetime(0) DEFAULT NULL,
    `chat_session_id` int DEFAULT NULL,
    PRIMARY KEY (`chat_message_id`),
    FOREIGN KEY (`chat_session_id`) REFERENCES `chat_session` (`chat_session_id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
